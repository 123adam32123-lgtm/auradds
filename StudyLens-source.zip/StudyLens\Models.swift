import Foundation

enum GeminiModelConfiguration {
    static let defaultModel = "gemini-3.5-flash-lite"
    static let defaultResponseLength = ResponseLength.standard.rawValue
}

enum ResponseLength: String, CaseIterable, Identifiable {
    case concise
    case standard
    case detailed

    var id: String { rawValue }

    var title: String { rawValue.capitalized }

    var maxOutputTokens: Int {
        switch self {
        case .concise: 700
        case .standard: 1_200
        case .detailed: 2_000
        }
    }
}

struct StudyResult: Decodable, Equatable {
    let question: String
    let concepts: String
    let approach: [String]
    let tryItYourself: String
    let suggestedSolution: String

    static func from(modelText: String) -> StudyResult {
        let cleanedText = modelText
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        if let data = cleanedText.data(using: .utf8),
           let result = try? JSONDecoder().decode(StudyResult.self, from: data) {
            return result
        }

        return StudyResult(
            question: "Gemini returned an unstructured response.",
            concepts: "Review the explanation below and compare it with your course material.",
            approach: [modelText],
            tryItYourself: "Try working through the problem before relying on the suggested solution.",
            suggestedSolution: "See the explanation above."
        )
    }
}

enum StudyAssistantError: LocalizedError {
    case missingAPIKey
    case invalidImage
    case imageTooLarge
    case noReadableContent
    case network(URLError)
    case api(statusCode: Int, message: String)
    case malformedResponse

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "Add a Gemini API key in Settings before analyzing an image."
        case .invalidImage:
            return "The image could not be prepared for analysis. Try another image."
        case .imageTooLarge:
            return "The image is too large to send. Try a smaller or lower-resolution image."
        case .noReadableContent:
            return "The image is too blurry or unclear to analyze. Try taking another photo."
        case .network:
            return "Could not connect to Gemini. Check your internet connection and try again."
        case let .api(statusCode, message):
            switch statusCode {
            case 401, 403:
                return "The Gemini API key was rejected. Check the key in Settings."
            case 429:
                return "Gemini has temporarily limited requests. Please try again later."
            default:
                return message.isEmpty ? "Gemini could not process the request. Please try again." : message
            }
        case .malformedResponse:
            return "Gemini returned a response that could not be read. Please try again."
        }
    }
}
