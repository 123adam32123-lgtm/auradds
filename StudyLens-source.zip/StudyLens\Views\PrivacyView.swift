import SwiftUI

struct PrivacyView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("What is sent") {
                    Text("When you tap Analyze Selected Image, the selected or captured image and the learning prompt are sent to Google’s Gemini API.")
                }
                Section("What stays on this device") {
                    Text("Your Gemini API key is stored in the iOS Keychain. StudyLens does not store it in UserDefaults.")
                    Text("Images are held in memory for the active study session and are not saved permanently by StudyLens unless you save them yourself.")
                }
                Section("Your control") {
                    Text("You choose each image to analyze. You can remove your API key at any time in Settings.")
                }
            }
            .navigationTitle("Privacy")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
