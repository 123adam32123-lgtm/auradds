import SwiftUI

struct RootView: View {
    @EnvironmentObject private var appState: AppState

    var body: some View {
        Group {
            if appState.isConfigured {
                DashboardView()
            } else {
                APIKeySetupView()
            }
        }
        .animation(.easeInOut, value: appState.isConfigured)
    }
}
