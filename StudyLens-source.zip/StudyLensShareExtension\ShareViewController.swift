import Social
import UniformTypeIdentifiers
import UIKit

final class ShareViewController: SLComposeServiceViewController {
    private let appGroupIdentifier = "group.com.example.StudyLens"
    private let pendingImageFilenameKey = "pendingSharedImageFilename"

    override func isContentValid() -> Bool { true }

    override func didSelectPost() {
        guard let item = extensionContext?.inputItems.first as? NSExtensionItem,
              let provider = item.attachments?.first(where: { $0.hasItemConformingToTypeIdentifier(UTType.image.identifier) }) else {
            complete()
            return
        }

        provider.loadDataRepresentation(forTypeIdentifier: UTType.image.identifier) { [weak self] data, _ in
            guard let self, let data, let image = UIImage(data: data),
                  let imageData = image.jpegData(compressionQuality: 0.85),
                  let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: self.appGroupIdentifier),
                  let defaults = UserDefaults(suiteName: self.appGroupIdentifier) else {
                self?.complete()
                return
            }

            let filename = "shared-study-image-\(UUID().uuidString).jpg"
            do {
                try imageData.write(to: container.appendingPathComponent(filename), options: .atomic)
                defaults.set(filename, forKey: self.pendingImageFilenameKey)
            } catch {
                // The host app will show an image-selection error if the shared data cannot be read.
            }
            self.complete()
        }
    }

    override func configurationItems() -> [Any]! { [] }

    private func complete() {
        DispatchQueue.main.async {
            self.extensionContext?.completeRequest(returningItems: nil)
        }
    }
}
