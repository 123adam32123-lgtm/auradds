import SwiftUI

struct StudyResultSheet: View {
    let result: StudyResult
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    resultSection("What the question asks", icon: "questionmark.circle", text: result.question)
                    resultSection("Relevant concepts", icon: "lightbulb", text: result.concepts)
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Step-by-step approach", systemImage: "list.number")
                            .font(.headline)
                        ForEach(Array(result.approach.enumerated()), id: \.offset) { index, step in
                            HStack(alignment: .top, spacing: 10) {
                                Text("\(index + 1)")
                                    .font(.caption.bold())
                                    .foregroundStyle(.white)
                                    .frame(width: 24, height: 24)
                                    .background(.indigo, in: Circle())
                                Text(step)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    .padding()
                    .background(.indigo.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
                    resultSection("Try it yourself", icon: "pencil.and.list.clipboard", text: result.tryItYourself)
                    resultSection("Suggested Solution", icon: "checkmark.seal", text: result.suggestedSolution, accent: .green)
                }
                .padding()
            }
            .navigationTitle("Study Guide")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }

    private func resultSection(_ title: String, icon: String, text: String, accent: Color = .indigo) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: icon)
                .font(.headline)
                .foregroundStyle(accent)
            Text(text)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
    }
}
