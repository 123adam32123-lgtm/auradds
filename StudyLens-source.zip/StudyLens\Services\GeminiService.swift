import Foundation
import UIKit

struct GeminiService {
    private let session: URLSession

    init(session: URLSession = .shared) {
        self.session = session
    }

    func validate(apiKey: String, model: String) async throws {
        let request = GeminiRequest(
            contents: [GeminiContent(parts: [.text("Reply with the word valid.")])],
            generationConfig: GeminiGenerationConfig(maxOutputTokens: 16)
        )
        _ = try await send(request, apiKey: apiKey, model: model)
    }

    func analyze(image: UIImage, apiKey: String, model: String, responseLength: ResponseLength) async throws -> StudyResult {
        guard !apiKey.isEmpty else { throw StudyAssistantError.missingAPIKey }
        let payload = try ImagePayload(image: image)
        let prompt = """
        You are StudyLens, a learning assistant. Analyze this user-provided educational image.
        Teach the learner rather than returning an unexplained answer. Identify the problem, explain the relevant concepts, give a clear worked method, ask the learner to try an important step, and then provide a clearly labelled suggested solution.
        If the image is unreadable or does not contain educational content, say so clearly.
        Return ONLY valid JSON with this exact shape:
        {"question":"...","concepts":"...","approach":["..."],"tryItYourself":"...","suggestedSolution":"..."}
        """
        let request = GeminiRequest(
            contents: [GeminiContent(parts: [
                .inlineImage(payload),
                .text(prompt)
            ])],
            generationConfig: GeminiGenerationConfig(
                maxOutputTokens: responseLength.maxOutputTokens,
                responseMimeType: "application/json"
            )
        )
        let response = try await send(request, apiKey: apiKey, model: model)
        guard let text = response.candidates?.first?.content.parts.compactMap(\.text).joined(separator: "\n"), !text.isEmpty else {
            throw StudyAssistantError.malformedResponse
        }
        let result = StudyResult.from(modelText: text)
        if result.question.localizedCaseInsensitiveContains("unreadable") {
            throw StudyAssistantError.noReadableContent
        }
        return result
    }

    private func send(_ payload: GeminiRequest, apiKey: String, model: String) async throws -> GeminiResponse {
        guard let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent") else {
            throw StudyAssistantError.malformedResponse
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "x-goog-api-key")
        request.timeoutInterval = 60
        request.httpBody = try JSONEncoder().encode(payload)

        do {
            let (data, response) = try await session.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse else {
                throw StudyAssistantError.malformedResponse
            }
            guard (200...299).contains(httpResponse.statusCode) else {
                let error = try? JSONDecoder().decode(GeminiAPIErrorEnvelope.self, from: data)
                throw StudyAssistantError.api(statusCode: httpResponse.statusCode, message: error?.error.message ?? "")
            }
            return try JSONDecoder().decode(GeminiResponse.self, from: data)
        } catch let error as StudyAssistantError {
            throw error
        } catch let error as URLError {
            throw StudyAssistantError.network(error)
        } catch {
            throw StudyAssistantError.malformedResponse
        }
    }
}

private struct ImagePayload {
    let mimeType: String
    let data: String

    init(image: UIImage) throws {
        let normalized = image.scaledToFit(maxDimension: 2_000)
        guard let jpegData = normalized.jpegData(compressionQuality: 0.78) else {
            throw StudyAssistantError.invalidImage
        }
        guard jpegData.count < 18_000_000 else { throw StudyAssistantError.imageTooLarge }
        self.mimeType = "image/jpeg"
        self.data = jpegData.base64EncodedString()
    }
}

private extension UIImage {
    func scaledToFit(maxDimension: CGFloat) -> UIImage {
        let longestSide = max(size.width, size.height)
        guard longestSide > maxDimension else { return self }
        let scale = maxDimension / longestSide
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in draw(in: CGRect(origin: .zero, size: newSize)) }
    }
}

private struct GeminiRequest: Encodable {
    let contents: [GeminiContent]
    let generationConfig: GeminiGenerationConfig
}

private struct GeminiContent: Encodable {
    let parts: [GeminiPart]
}

private enum GeminiPart: Encodable {
    case text(String)
    case inlineImage(ImagePayload)

    enum CodingKeys: String, CodingKey { case text, inlineData = "inline_data" }
    enum InlineDataKeys: String, CodingKey { case mimeType = "mime_type", data }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case let .text(value):
            try container.encode(value, forKey: .text)
        case let .inlineImage(payload):
            var imageContainer = container.nestedContainer(keyedBy: InlineDataKeys.self, forKey: .inlineData)
            try imageContainer.encode(payload.mimeType, forKey: .mimeType)
            try imageContainer.encode(payload.data, forKey: .data)
        }
    }
}

private struct GeminiGenerationConfig: Encodable {
    let maxOutputTokens: Int
    let responseMimeType: String?

    init(maxOutputTokens: Int, responseMimeType: String? = nil) {
        self.maxOutputTokens = maxOutputTokens
        self.responseMimeType = responseMimeType
    }

    enum CodingKeys: String, CodingKey {
        case maxOutputTokens = "maxOutputTokens"
        case responseMimeType = "responseMimeType"
    }
}

private struct GeminiResponse: Decodable {
    let candidates: [GeminiCandidate]?
}

private struct GeminiCandidate: Decodable {
    let content: GeminiResponseContent
}

private struct GeminiResponseContent: Decodable {
    let parts: [GeminiResponsePart]
}

private struct GeminiResponsePart: Decodable {
    let text: String?
}

private struct GeminiAPIErrorEnvelope: Decodable {
    let error: GeminiAPIError
}

private struct GeminiAPIError: Decodable {
    let message: String
}
