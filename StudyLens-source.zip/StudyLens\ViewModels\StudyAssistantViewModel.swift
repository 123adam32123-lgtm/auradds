import Foundation
import PhotosUI
import SwiftUI
import UIKit

@MainActor
final class StudyAssistantViewModel: ObservableObject {
    @Published var selectedImage: UIImage?
    @Published var result: StudyResult?
    @Published var isAnalyzing = false
    @Published var errorMessage: String?

    private let geminiService: GeminiService

    init(geminiService: GeminiService = GeminiService()) {
        self.geminiService = geminiService
    }

    func loadPhotoPickerItem(_ item: PhotosPickerItem?) async {
        guard let item else { return }
        do {
            guard let data = try await item.loadTransferable(type: Data.self), let image = UIImage(data: data) else {
                errorMessage = "The selected image could not be opened. Try another image."
                return
            }
            select(image)
        } catch {
            errorMessage = "The selected image could not be opened. Try another image."
        }
    }

    func loadSharedImageIfAvailable() {
        if let image = ShareSheetService.consumePendingImage() {
            select(image)
        }
    }

    func select(_ image: UIImage) {
        selectedImage = image
        result = nil
        errorMessage = nil
    }

    func analyze(model: String, responseLength: ResponseLength) async {
        guard let selectedImage else {
            errorMessage = "Select or capture an educational image before analyzing it."
            return
        }
        do {
            guard let apiKey = try KeychainManager.shared.readAPIKey(), !apiKey.isEmpty else {
                throw StudyAssistantError.missingAPIKey
            }
            isAnalyzing = true
            errorMessage = nil
            result = try await geminiService.analyze(
                image: selectedImage,
                apiKey: apiKey,
                model: model,
                responseLength: responseLength
            )
        } catch {
            errorMessage = (error as? LocalizedError)?.errorDescription ?? "Something went wrong. Please try again."
        }
        isAnalyzing = false
    }
}
