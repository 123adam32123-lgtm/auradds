import Foundation
import UIKit

enum ShareSheetService {
    static let appGroupIdentifier = "group.com.example.StudyLens"
    private static let pendingImageFilenameKey = "pendingSharedImageFilename"

    static func consumePendingImage() -> UIImage? {
        guard let defaults = UserDefaults(suiteName: appGroupIdentifier),
              let filename = defaults.string(forKey: pendingImageFilenameKey),
              let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupIdentifier) else {
            return nil
        }
        let fileURL = container.appendingPathComponent(filename)
        defer {
            defaults.removeObject(forKey: pendingImageFilenameKey)
            try? FileManager.default.removeItem(at: fileURL)
        }
        return UIImage(contentsOfFile: fileURL.path)
    }
}
