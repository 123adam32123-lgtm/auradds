import SwiftUI

struct APIKeySetupView: View {
    @EnvironmentObject private var appState: AppState
    @AppStorage("geminiModel") private var model = GeminiModelConfiguration.defaultModel
    @State private var apiKey = ""
    @State private var isValidating = false
    @State private var errorMessage: String?
    private let geminiService = GeminiService()

    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            Image(systemName: "graduationcap.circle.fill")
                .font(.system(size: 72))
                .foregroundStyle(.indigo)
            VStack(spacing: 8) {
                Text("Welcome to StudyLens")
                    .font(.largeTitle.bold())
                Text("Add your own Gemini API key to start analyzing study material. Your key stays securely on this device.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal)

            VStack(alignment: .leading, spacing: 10) {
                Text("Gemini API key")
                    .font(.headline)
                SecureField("Paste your API key", text: $apiKey)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textContentType(.password)
                    .padding(14)
                    .background(.quaternary, in: RoundedRectangle(cornerRadius: 12))
                if let errorMessage {
                    Label(errorMessage, systemImage: "exclamationmark.triangle.fill")
                        .font(.footnote)
                        .foregroundStyle(.red)
                }
            }
            .padding(.horizontal, 24)

            Button(action: validateAndSave) {
                HStack {
                    if isValidating { ProgressView().tint(.white) }
                    Text(isValidating ? "Validating…" : "Validate API Key")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(isValidating || apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            .padding(.horizontal, 24)

            Text("Images you analyze are sent directly to Google’s Gemini API. StudyLens does not permanently save them.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            Spacer()
        }
        .padding(.vertical, 28)
    }

    private func validateAndSave() {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        Task {
            isValidating = true
            errorMessage = nil
            do {
                try await geminiService.validate(apiKey: key, model: model)
                try appState.saveAPIKey(key)
            } catch {
                errorMessage = (error as? LocalizedError)?.errorDescription ?? "The API key could not be validated."
            }
            isValidating = false
        }
    }
}
