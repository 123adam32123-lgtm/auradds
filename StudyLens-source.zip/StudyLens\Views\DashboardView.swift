import PhotosUI
import SwiftUI

struct DashboardView: View {
    @AppStorage("geminiModel") private var model = GeminiModelConfiguration.defaultModel
    @AppStorage("responseLength") private var responseLengthRawValue = GeminiModelConfiguration.defaultResponseLength
    @StateObject private var viewModel = StudyAssistantViewModel()
    @State private var photoPickerItem: PhotosPickerItem?
    @State private var isShowingCamera = false
    @State private var isShowingSettings = false
    @State private var isShowingPrivacy = false

    private var responseLength: ResponseLength {
        ResponseLength(rawValue: responseLengthRawValue) ?? .standard
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    statusCard
                    imageSelectionCard
                    modelCard
                    capabilityNote
                }
                .padding()
            }
            .navigationTitle("StudyLens")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { isShowingPrivacy = true } label: {
                        Image(systemName: "hand.raised")
                    }
                    .accessibilityLabel("Privacy information")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { isShowingSettings = true } label: {
                        Image(systemName: "gearshape")
                    }
                    .accessibilityLabel("Settings")
                }
            }
            .onChange(of: photoPickerItem) { _, item in
                Task { await viewModel.loadPhotoPickerItem(item) }
            }
            .onAppear { viewModel.loadSharedImageIfAvailable() }
            .sheet(item: $viewModel.result) { result in
                StudyResultSheet(result: result)
            }
            .sheet(isPresented: $isShowingSettings) { SettingsView() }
            .sheet(isPresented: $isShowingPrivacy) { PrivacyView() }
            .fullScreenCover(isPresented: $isShowingCamera) {
                CameraPicker(
                    onImageCaptured: viewModel.select,
                    onUnavailable: { viewModel.errorMessage = "The camera could not capture an image. Please try again." }
                )
            }
            .alert("StudyLens", isPresented: Binding(
                get: { viewModel.errorMessage != nil },
                set: { if !$0 { viewModel.errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(viewModel.errorMessage ?? "")
            }
        }
    }

    private var statusCard: some View {
        HStack(spacing: 14) {
            Image(systemName: "checkmark.seal.fill")
                .font(.system(size: 38))
                .foregroundStyle(.green)
            VStack(alignment: .leading, spacing: 3) {
                Text("AI MODULE: ENABLED")
                    .font(.headline.monospaced())
                Text("Your Gemini API key is securely stored in Keychain.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding()
        .background(.green.opacity(0.12), in: RoundedRectangle(cornerRadius: 18))
    }

    private var imageSelectionCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Educational image")
                .font(.title3.bold())
            if let image = viewModel.selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 280)
                    .frame(maxWidth: .infinity)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .accessibilityLabel("Selected educational image")
            } else {
                ContentUnavailableView("No image selected", systemImage: "photo.on.rectangle", description: Text("Choose a worksheet, diagram, textbook problem, or other study material."))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 20)
            }
            HStack {
                PhotosPicker(selection: $photoPickerItem, matching: .images) {
                    Label("Photos", systemImage: "photo")
                }
                .buttonStyle(.bordered)
                Button {
                    if CameraPicker.isAvailable() { isShowingCamera = true }
                    else { viewModel.errorMessage = "Camera is unavailable on this device. Select an image from Photos instead." }
                } label: {
                    Label("Camera", systemImage: "camera")
                }
                .buttonStyle(.bordered)
            }
            Button {
                Task { await viewModel.analyze(model: model, responseLength: responseLength) }
            } label: {
                HStack {
                    if viewModel.isAnalyzing { ProgressView().tint(.white) }
                    Text(viewModel.isAnalyzing ? "Analyzing…" : "Analyze Selected Image")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(viewModel.selectedImage == nil || viewModel.isAnalyzing)
        }
        .padding()
        .background(.background, in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.quaternary))
    }

    private var modelCard: some View {
        Label {
            VStack(alignment: .leading, spacing: 2) {
                Text("Current model")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Text(model)
                    .font(.body.monospaced())
            }
        } icon: {
            Image(systemName: "sparkles")
                .foregroundStyle(.indigo)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.indigo.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
    }

    private var capabilityNote: some View {
        // iOS third-party apps cannot capture other apps, intercept system volume buttons, or draw global overlays.
        Label("StudyLens only analyzes images you explicitly select, receive via its Share extension, or capture with its in-app camera.", systemImage: "info.circle")
            .font(.footnote)
            .foregroundStyle(.secondary)
    }
}

extension StudyResult: Identifiable {
    var id: String { question + suggestedSolution }
}
