import Foundation

@MainActor
final class AppState: ObservableObject {
    @Published private(set) var isConfigured = false

    init() {
        reloadConfiguration()
    }

    func reloadConfiguration() {
        isConfigured = (try? KeychainManager.shared.readAPIKey())?.isEmpty == false
    }

    func saveAPIKey(_ apiKey: String) throws {
        try KeychainManager.shared.saveAPIKey(apiKey)
        isConfigured = true
    }

    func removeAPIKey() throws {
        try KeychainManager.shared.deleteAPIKey()
        isConfigured = false
    }
}
