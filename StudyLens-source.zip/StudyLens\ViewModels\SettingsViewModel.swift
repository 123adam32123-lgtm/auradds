import Foundation

@MainActor
final class SettingsViewModel: ObservableObject {
    @Published var apiKeyInput = ""
    @Published var isValidating = false
    @Published var errorMessage: String?
    @Published var confirmationMessage: String?

    private let geminiService: GeminiService

    init(geminiService: GeminiService = GeminiService()) {
        self.geminiService = geminiService
    }

    func updateAPIKey(model: String, appState: AppState) async {
        let trimmedKey = apiKeyInput.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedKey.isEmpty else {
            errorMessage = "Enter a Gemini API key."
            return
        }
        isValidating = true
        errorMessage = nil
        confirmationMessage = nil
        do {
            try await geminiService.validate(apiKey: trimmedKey, model: model)
            try appState.saveAPIKey(trimmedKey)
            apiKeyInput = ""
            confirmationMessage = "Your API key was securely updated."
        } catch {
            errorMessage = (error as? LocalizedError)?.errorDescription ?? "The API key could not be validated."
        }
        isValidating = false
    }
}
