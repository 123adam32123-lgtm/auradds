import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var appState: AppState
    @Environment(\.dismiss) private var dismiss
    @AppStorage("geminiModel") private var model = GeminiModelConfiguration.defaultModel
    @AppStorage("responseLength") private var responseLengthRawValue = GeminiModelConfiguration.defaultResponseLength
    @StateObject private var viewModel = SettingsViewModel()
    @State private var isShowingPrivacy = false
    @State private var isShowingRemoveConfirmation = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Gemini API key") {
                    SecureField("New API key", text: $viewModel.apiKeyInput)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button(viewModel.isValidating ? "Validating…" : "Validate and Update Key") {
                        Task { await viewModel.updateAPIKey(model: model, appState: appState) }
                    }
                    .disabled(viewModel.isValidating || viewModel.apiKeyInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    Button("Remove API Key", role: .destructive) {
                        isShowingRemoveConfirmation = true
                    }
                }

                if let confirmation = viewModel.confirmationMessage {
                    Section { Text(confirmation).foregroundStyle(.green) }
                }
                if let errorMessage = viewModel.errorMessage {
                    Section { Text(errorMessage).foregroundStyle(.red) }
                }

                Section("Study preferences") {
                    TextField("Gemini model", text: $model)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Picker("Response length", selection: $responseLengthRawValue) {
                        ForEach(ResponseLength.allCases) { length in
                            Text(length.title).tag(length.rawValue)
                        }
                    }
                }

                Section("Privacy") {
                    Button("How StudyLens handles your data") { isShowingPrivacy = true }
                }

                Section("About") {
                    LabeledContent("Version", value: "1.0")
                    Text("StudyLens is designed for learner-initiated study and explanation.")
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .sheet(isPresented: $isShowingPrivacy) { PrivacyView() }
            .confirmationDialog("Remove your Gemini API key?", isPresented: $isShowingRemoveConfirmation, titleVisibility: .visible) {
                Button("Remove Key", role: .destructive) {
                    do { try appState.removeAPIKey() }
                    catch { viewModel.errorMessage = "The API key could not be removed. Please try again." }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("You will need to validate a new key before using StudyLens again.")
            }
        }
    }
}
